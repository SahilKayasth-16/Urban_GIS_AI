@router.get("analytics/overview")
def analytics_overview():
    query: """
    SELECT 
	p.area_name,
	p.population,
	p.area_sq_km,
	ROUND((p.population:: numeric / p.area_sq_km:: numeric), 2) AS population_density,
	ROUND(
		(u.water_supply_score + 
         u.electricity_score + 
         u.sewage_score + 
         u.road_connectivity_score + 
         u.internet_score)::numeric / 5, 
         1
	) AS utility_index
    FROM area_population p
    JOIN area_utilities u
    ON p.area_name = u.area_name;
    """
    
    rows = db.execute(query).fetchall()

    return {
        "city": "Ahmedabad",
        "results": [
            {
                "area": r[0],
                "population": r[1],
                "area_sq_km": r[2],
                "population_density": r[3],
                "utility_index": r[4]
            } for r in rows
        ]
    }
